package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Conexao;

/**
 * Servlet implementation class atualizar
 */
@WebServlet("/atualizar")
public class atualizar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		
		
		
		

        int id = Integer.parseInt(request.getParameter("id"));
        String descricao = request.getParameter("descricao");

        try (Connection conn = Conexao.getConexao();
             PreparedStatement st = conn.prepareStatement(
                     "UPDATE Status SET descricao = ? WHERE id_status = ?")) {

            st.setString(1, descricao);
            st.setInt(2, id);
            int linhas = st.executeUpdate();

            if (linhas > 0) {
                response.sendRedirect("mostrarS");
            } else {
                response.getWriter().println("<h2>Erro: Nenhum status foi atualizado.</h2>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h2>Erro ao atualizar: " + e.getMessage() + "</h2>");
        }
    
	}

}
