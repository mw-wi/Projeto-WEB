package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;


import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Conexao;


@WebServlet("/StatusServlet")
public class StatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {

		String desc = req.getParameter("descricao");

		String sql = "INSERT INTO Status (descricao) VALUES (?)";

		try (Connection conn = Conexao.getConexao(); PreparedStatement st = conn.prepareStatement(sql)) {

			st.setString(1, desc);
			st.executeUpdate();

			resp.sendRedirect("MenuIncidente.html");

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	
}
