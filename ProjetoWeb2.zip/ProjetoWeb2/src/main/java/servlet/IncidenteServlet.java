package servlet;

import java.io.*;
import java.sql.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import util.Conexao;

@WebServlet("/api/*")
public class IncidenteServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    // Tabelas válidas do seu projeto
    private final String[] tabelasValidas = {
        "incidente", "usuario", "tecnico", "servico", "status", "atualizacao"
    };

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        processRequest(req, resp, "GET");
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        processRequest(req, resp, "POST");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        processRequest(req, resp, "PUT");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        processRequest(req, resp, "DELETE");
    }

    private void processRequest(HttpServletRequest req, HttpServletResponse resp, String metodo) throws IOException {
        resp.setContentType("application/json;charset=UTF-8");
        PrintWriter out = resp.getWriter();

        try (Connection conn = Conexao.getConexao()) {

            // Obtém a tabela e ID da URL
            String path = req.getPathInfo(); // /incidente ou /usuario/1
            if (path == null || path.equals("/")) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"erro\":\"Informe o recurso na URL, ex: /api/incidente\"}");
                return;
            }

            String[] parts = path.split("/");
            String tabela = parts[1].toLowerCase();
            if (!isTabelaValida(tabela)) {
                resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                out.print("{\"erro\":\"Recurso inválido: " + tabela + "\"}");
                return;
            }

            Integer id = (parts.length >= 3) ? Integer.parseInt(parts[2]) : null;

            switch (metodo) {
                case "GET": executarGet(conn, tabela, id, out); break;
                case "POST": executarPost(conn, req, tabela, out); break;
                case "PUT": executarPut(conn, req, tabela, id, out); break;
                case "DELETE": executarDelete(conn, tabela, id, out); break;
            }

        } catch (NumberFormatException e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"erro\":\"ID inválido na URL\"}");
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"erro\":\"" + e.getMessage() + "\"}");
        }
    }

    // =================== CRUD ====================

    private boolean isTabelaValida(String tabela) {
        for (String t : tabelasValidas) if (t.equals(tabela)) return true;
        return false;
    }

    private void executarGet(Connection conn, String tabela, Integer id, PrintWriter out) throws SQLException {
        ResultSet rs;
        if (id == null) {
            Statement stmt = conn.createStatement();
            rs = stmt.executeQuery("SELECT * FROM " + tabela);
            out.print(resultSetToJsonArray(rs));
        } else {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM " + tabela + " WHERE id_" + tabela + "=?");
            ps.setInt(1, id);
            rs = ps.executeQuery();
            if (rs.next()) out.print(resultSetToJsonObject(rs));
            else out.print("{\"erro\":\"Registro não encontrado\"}");
        }
    }

    private void executarPost(Connection conn, HttpServletRequest req, String tabela, PrintWriter out) throws SQLException, IOException {
        var dados = parseFormData(req);
        if (dados.isEmpty()) { out.print("{\"erro\":\"Nenhum dado enviado\"}"); return; }

        String sql = "INSERT INTO " + tabela + " (" + String.join(",", dados.keySet()) + ") VALUES (" +
                     "?,".repeat(dados.size()).replaceAll(",$","") + ")";
        PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        int i = 1;
        for (String key : dados.keySet()) ps.setString(i++, dados.get(key));
        ps.executeUpdate();
        ResultSet keys = ps.getGeneratedKeys();
        if (keys.next()) out.print("{\"mensagem\":\"Registro inserido\",\"id\":" + keys.getInt(1) + "}");
        else out.print("{\"mensagem\":\"Registro inserido\"}");
    }

    private void executarPut(Connection conn, HttpServletRequest req, String tabela, Integer id, PrintWriter out) throws SQLException, IOException {
        if (id == null) { out.print("{\"erro\":\"Informe o ID na URL\"}"); return; }
        var dados = parseFormData(req);
        if (dados.isEmpty()) { out.print("{\"erro\":\"Nenhum dado enviado\"}"); return; }

        StringBuilder sb = new StringBuilder("UPDATE " + tabela + " SET ");
        for (String key : dados.keySet()) sb.append(key).append("=?,");
        sb.deleteCharAt(sb.length()-1);
        sb.append(" WHERE id_" + tabela + "=?");

        PreparedStatement ps = conn.prepareStatement(sb.toString());
        int i = 1;
        for (String key : dados.keySet()) ps.setString(i++, dados.get(key));
        ps.setInt(i, id);
        int updated = ps.executeUpdate();
        if (updated>0) out.print("{\"mensagem\":\"Registro atualizado\"}");
        else out.print("{\"erro\":\"Registro não encontrado\"}");
    }

    private void executarDelete(Connection conn, String tabela, Integer id, PrintWriter out) throws SQLException {
        if (id == null) { out.print("{\"erro\":\"Informe o ID na URL\"}"); return; }
        PreparedStatement ps = conn.prepareStatement("DELETE FROM " + tabela + " WHERE id_" + tabela + "=?");
        ps.setInt(1, id);
        int deleted = ps.executeUpdate();
        if (deleted>0) out.print("{\"mensagem\":\"Registro deletado\"}");
        else out.print("{\"erro\":\"Registro não encontrado\"}");
    }

    // =================== UTIL ====================

    private java.util.Map<String,String> parseFormData(HttpServletRequest req) throws IOException {
        var dados = new java.util.LinkedHashMap<String,String>();
        BufferedReader reader = req.getReader();
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        String body = sb.toString();
        if (!body.isEmpty()) {
            String[] pairs = body.split("&");
            for (String pair : pairs) {
                String[] kv = pair.split("=");
                if (kv.length==2) dados.put(kv[0], kv[1]);
            }
        }
        return dados;
    }

    private String resultSetToJsonArray(ResultSet rs) throws SQLException {
        StringBuilder sb = new StringBuilder("[");
        boolean first = true;
        while (rs.next()) {
            if (!first) sb.append(",");
            sb.append(resultSetToJsonObject(rs));
            first = false;
        }
        sb.append("]");
        return sb.toString();
    }

    private String resultSetToJsonObject(ResultSet rs) throws SQLException {
        StringBuilder sb = new StringBuilder("{");
        ResultSetMetaData md = rs.getMetaData();
        for (int i=1;i<=md.getColumnCount();i++) {
            Object val = rs.getObject(i);
            sb.append("\"").append(md.getColumnName(i)).append("\":");
            if (val==null) sb.append("null");
            else if (val instanceof Number) sb.append(val);
            else sb.append("\"").append(val.toString().replace("\"","\\\"")).append("\"");
            if (i<md.getColumnCount()) sb.append(",");
        }
        sb.append("}");
        return sb.toString();
    }
}
