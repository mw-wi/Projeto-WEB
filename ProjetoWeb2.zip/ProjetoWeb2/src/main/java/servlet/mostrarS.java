package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Conexao;
import util.Status;

/**
 * Servlet implementation class mostrarS
 */
@WebServlet("/mostrarS")
public class mostrarS extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		String sql = "SELECT * FROM Status";
		 List<Status> lista = new ArrayList<>();
        try (Connection conn = Conexao.getConexao();
             PreparedStatement st = conn.prepareStatement(sql);
             ResultSet rs = st.executeQuery()) {

            while (rs.next()) {
                Status s = new Status();
                s.setId(rs.getInt("id_status"));
                s.setDescricao(rs.getString("descricao"));
                lista.add(s);
            }

        
            request.setAttribute("listaStatus", lista);

          try {
                request.getRequestDispatcher("verStatus.jsp").forward(request, response);
            } catch (Exception e) {
                e.printStackTrace();
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h2>Erro ao listar status: " + e.getMessage() + "</h2>");
        }
    }
	}

	

