package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Conexao;

/**
 * Servlet implementation class deletar
 */
@WebServlet("/deletar")
public class deletar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

        int id = Integer.parseInt(request.getParameter("id"));

        try (Connection conn = Conexao.getConexao();
             PreparedStatement st = conn.prepareStatement("DELETE FROM Status WHERE id_status = ?")) {

            st.setInt(1, id);
            int linhas = st.executeUpdate();

            if (linhas > 0) {
                response.sendRedirect("mostrarS");
            } else {
                response.getWriter().println("<h2>Erro: Status não encontrado para exclusão.</h2>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h2>Erro ao excluir: " + e.getMessage() + "</h2>");
        }
    }
		
	

	

}
