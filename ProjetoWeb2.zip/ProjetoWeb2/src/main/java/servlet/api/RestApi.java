package servlet.api;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import util.Conexao;
import util.Status;

/**
 * Servlet implementation class RestApi
 */
@WebServlet("/RestApi/*")
public class RestApi extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	 private Gson gson = new Gson();

	    // -------------------------------
	    // GET → lista todos ou busca por ID
	    // -------------------------------
	 @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        resp.setContentType("application/json; charset=UTF-8");
	        String idParam = req.getParameter("id");

	        try (Connection conn = Conexao.getConexao()) {
	            if (idParam != null) {
	                // Buscar 1 registro
	                int id = Integer.parseInt(idParam);
	                String sql = "SELECT * FROM Status WHERE id_status = ?";
	                try (PreparedStatement st = conn.prepareStatement(sql)) {
	                    st.setInt(1, id);
	                    ResultSet rs = st.executeQuery();
	                    if (rs.next()) {
	                        Status s = new Status();
	                        s.setId(rs.getInt("id_status"));
	                        s.setDescricao(rs.getString("descricao"));
	                        resp.getWriter().print(gson.toJson(s));
	                    } else {
	                        resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
	                        resp.getWriter().print("{\"erro\":\"Status não encontrado\"}");
	                    }
	                }
	            } else {
	                // Buscar todos
	                List<Status> lista = new ArrayList<>();
	                String sql = "SELECT * FROM Status";
	                try (PreparedStatement st = conn.prepareStatement(sql);
	                     ResultSet rs = st.executeQuery()) {
	                    while (rs.next()) {
	                        Status s = new Status();
	                        s.setId(rs.getInt("id_status"));
	                        s.setDescricao(rs.getString("descricao"));
	                        lista.add(s);
	                    }
	                }
	                resp.getWriter().print(gson.toJson(lista));
	            }
	        } catch (Exception e) {
	            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            resp.getWriter().print("{\"erro\":\"Erro ao listar: " + e.getMessage() + "\"}");
	        }
	    }

	    // ✅ CRIAR (POST)
	    @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        resp.setContentType("application/json; charset=UTF-8");
	        try {
	            Status s = gson.fromJson(req.getReader(), Status.class);

	            try (Connection conn = Conexao.getConexao();
	                 PreparedStatement st = conn.prepareStatement("INSERT INTO Status (descricao) VALUES (?)")) {
	                st.setString(1, s.getDescricao());
	                st.executeUpdate();
	            }

	            resp.getWriter().print("{\"mensagem\":\"Status criado com sucesso!\"}");
	        } catch (Exception e) {
	            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            resp.getWriter().print("{\"erro\":\"Erro ao criar: " + e.getMessage() + "\"}");
	        }
	    }

	    // ✅ ATUALIZAR (PUT)
	    @Override
	    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        resp.setContentType("application/json; charset=UTF-8");
	        try {
	            Status s = gson.fromJson(req.getReader(), Status.class);

	            try (Connection conn = Conexao.getConexao();
	                 PreparedStatement st = conn.prepareStatement(
	                         "UPDATE Status SET descricao = ? WHERE id_status = ?")) {
	                st.setString(1, s.getDescricao());
	                st.setInt(2, s.getId());
	                int linhas = st.executeUpdate();

	                if (linhas > 0) {
	                    resp.getWriter().print("{\"mensagem\":\"Status atualizado com sucesso!\"}");
	                } else {
	                    resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
	                    resp.getWriter().print("{\"erro\":\"Status não encontrado\"}");
	                }
	            }
	        } catch (Exception e) {
	            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            resp.getWriter().print("{\"erro\":\"Erro ao atualizar: " + e.getMessage() + "\"}");
	        }
	    }

	    // ✅ DELETAR (DELETE)
	    @Override
	    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws IOException {
	        resp.setContentType("application/json; charset=UTF-8");
	        String idParam = req.getParameter("id");

	        if (idParam == null) {
	            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
	            resp.getWriter().print("{\"erro\":\"Parâmetro 'id' é obrigatório\"}");
	            return;
	        }

	        try (Connection conn = Conexao.getConexao();
	             PreparedStatement st = conn.prepareStatement("DELETE FROM Status WHERE id_status = ?")) {
	            st.setInt(1, Integer.parseInt(idParam));
	            int linhas = st.executeUpdate();

	            if (linhas > 0) {
	                resp.getWriter().print("{\"mensagem\":\"Status deletado com sucesso!\"}");
	            } else {
	                resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
	                resp.getWriter().print("{\"erro\":\"Status não encontrado\"}");
	            }
	        } catch (Exception e) {
	            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
	            resp.getWriter().print("{\"erro\":\"Erro ao deletar: " + e.getMessage() + "\"}");
	        }
	    }}
