package servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.Conexao;
import util.Status;

/**
 * Servlet implementation class editar
 */
@WebServlet("/editar")
public class editar extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        int id = Integer.parseInt(request.getParameter("id"));

        try (Connection conn = Conexao.getConexao();
             PreparedStatement st = conn.prepareStatement("SELECT * FROM Status WHERE id_status=?")) {

            st.setInt(1, id);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                Status s = new Status();
                s.setId(rs.getInt("id_status"));
                s.setDescricao(rs.getString("descricao"));

               
                request.setAttribute("status", s);
                request.getRequestDispatcher("editarU.jsp").forward(request, response);

            } else {
                response.getWriter().println("<h2>Status não encontrado!</h2>");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("<h2>Erro ao buscar status: " + e.getMessage() + "</h2>");
        }
    }


}
